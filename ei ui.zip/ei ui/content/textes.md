# HEAD

Kazan - The ultimate competition of WorldSkills

The ultimate competition dedicated for any manuals and technologicals skills, loves and works just for fun, for their work or just exchanging their passion with others…

Entrez votre recherche

rechercher

# MENU
- Visits
- Contact
- History
- GetTickets

# HEADER
Augus 22 > 27
The ultimate competition dedicated for any manuals and technologicals skills, loves and works just for fun, for their work or just exchanging their passion with others…

Que faire à Kazan ?

# BUTTON
See Schedule

# GET TICKET
- Carte de crédit
- Paypal
₽2600 RUR

# FOOTER
TatarStan Toursim
Ulitsa Maksima Gor'kogo, 19, Kazan, 420015

Kazan (en russe, Казань ; en tatar : Казан) est une ville de Russie et la capitale de la république du Tatarstan, une des subdivisions de la Russie. Sa population s'élevait à 1 231 878 habitants en 2017 ce qui en fait la sixième ville de Russie.

Visit Tatarstan

+7 843-206-00-14
(speaker’s support)

Follow US
- #kazan2019
- @kazan2019



